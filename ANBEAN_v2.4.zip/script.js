
async function yukle(){
try{
const [u,e]=await Promise.all([
fetch('https://api.frankfurter.app/latest?from=USD&to=TRY').then(r=>r.json()),
fetch('https://api.frankfurter.app/latest?from=EUR&to=TRY').then(r=>r.json())
]);
usd.textContent=u.rates.TRY.toFixed(2)+' ₺';
eur.textContent=e.rates.TRY.toFixed(2)+' ₺';
}catch{}
try{
const a=await fetch('https://finans.truncgil.com/today.json').then(r=>r.json());
let g=a['Gram Altın'];
if(typeof g==='object') g=g['Alış']||Object.values(g)[0];
if(g) altin.textContent=String(g)+' ₺';
}catch{altin.textContent='Veri alınamadı';}
try{
const h=await fetch('https://api.open-meteo.com/v1/forecast?latitude=38.5&longitude=43.4&current=temperature_2m').then(r=>r.json());
hava.textContent=h.current.temperature_2m+'°C';
}catch{}
try{
const n=await fetch('https://api.aladhan.com/v1/timingsByCity?city=Van&country=Turkey&method=13').then(r=>r.json());
const t=n.data.timings;
namaz.innerHTML=`İmsak ${t.Fajr}<br>Öğle ${t.Dhuhr}<br>İkindi ${t.Asr}<br>Akşam ${t.Maghrib}<br>Yatsı ${t.Isha}`;
}catch{}
}
yukle();setInterval(yukle,60000);
document.getElementById('search').addEventListener('keydown',e=>{if(e.key==='Enter')alert('Arama yakında');});
